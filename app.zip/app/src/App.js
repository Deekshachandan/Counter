
import './App.css';
import {useState, useEffect} from "react"
import Timer from './Components/Timer';

function App() {
  
  return (
    <div className="App">
 <Timer />

    </div>
  );
}

export default App;
